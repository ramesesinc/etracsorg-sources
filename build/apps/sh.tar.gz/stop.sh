#!/bin/bash
cd /apps/server/bin
sh shutdown.sh
